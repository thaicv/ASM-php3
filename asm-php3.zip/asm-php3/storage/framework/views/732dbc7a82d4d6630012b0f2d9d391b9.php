<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Mukta:300,400,700">
<link rel="stylesheet" href="fonts/icomoon/style.css">

<link rel="stylesheet" href="/client/css/bootstrap.min.css">
<link rel="stylesheet" href="/client/css/magnific-popup.css">
<link rel="stylesheet" href="/client/css/jquery-ui.css">
<link rel="stylesheet" href="/client/css/owl.carousel.min.css">
<link rel="stylesheet" href="/client/css/owl.theme.default.min.css">


<link rel="stylesheet" href="/client/css/aos.css">

<link rel="stylesheet" href="/client/css/style.css">
<?php /**PATH C:\laragon\www\asm-php3\resources\views/client/layouts/partials/css.blade.php ENDPATH**/ ?>