<script src="/client/js/jquery-3.3.1.min.js"></script>
<script src="/client/js/jquery-ui.js"></script>
<script src="/client/js/popper.min.js"></script>
<script src="/client/js/bootstrap.min.js"></script>
<script src="/client/js/owl.carousel.min.js"></script>
<script src="/client/js/jquery.magnific-popup.min.js"></script>
<script src="/client/js/aos.js"></script>

<script src="/client/js/main.js"></script>
<?php /**PATH C:\laragon\www\asm-php3\resources\views/client/layouts/partials/js.blade.php ENDPATH**/ ?>